# ShinnThieuu Menu

This project is generated automatically by XcodeGen.

## Build
1. Push to GitHub.
2. Actions -> Build IPA.
3. XcodeGen creates `ShinnThieuuApp.xcodeproj` automatically.
