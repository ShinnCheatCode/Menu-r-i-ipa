#import "AppDelegate.h"
@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
 self.window=[[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
 UIViewController *vc=[UIViewController new];
 vc.view.backgroundColor=[UIColor colorWithWhite:0.05 alpha:1];
 UILabel *t=[[UILabel alloc] initWithFrame:CGRectMake(20,80,self.window.bounds.size.width-40,40)];
 t.text=@"SHINNTHIEUU ULTIMATE MENU"; t.textColor=[UIColor cyanColor];
 t.textAlignment=NSTextAlignmentCenter; t.font=[UIFont boldSystemFontOfSize:22];
 [vc.view addSubview:t];
 self.window.rootViewController=vc;
 [self.window makeKeyAndVisible];
 return YES;
}
@end