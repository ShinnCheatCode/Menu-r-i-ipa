# Direct IPA build

GitHub Actions runs `build.sh` directly on macOS-14 using the iPhoneOS SDK.

Output: `ShinnThieuuApp_Unsigned.ipa`

This is an unsigned IPA. Installation on a physical iPhone requires a valid signing/sideloading method.
