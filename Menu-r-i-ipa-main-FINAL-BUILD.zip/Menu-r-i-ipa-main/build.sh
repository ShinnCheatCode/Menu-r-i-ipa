#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
CC="$(xcrun --sdk iphoneos -f clang)"
CXX="$(xcrun --sdk iphoneos -f clang++)"

APP_NAME="ShinnThieuuApp"
BUILD="$ROOT/build"
APP="$BUILD/$APP_NAME.app"

rm -rf "$BUILD" "$ROOT/Payload" "$ROOT/${APP_NAME}_Unsigned.ipa"
mkdir -p "$APP"

"$CC" -isysroot "$SDK" -arch arm64 -miphoneos-version-min=17.0 \
  -fobjc-arc -c main.m -o "$BUILD/main.o"

"$CXX" -isysroot "$SDK" -arch arm64 -miphoneos-version-min=17.0 \
  -fobjc-arc -c AppDelegate.mm -o "$BUILD/AppDelegate.o"

OBJECTS=("$BUILD/main.o" "$BUILD/AppDelegate.o")

if [ -f builder.mm ]; then
  "$CXX" -isysroot "$SDK" -arch arm64 -miphoneos-version-min=17.0 \
    -fobjc-arc -c builder.mm -o "$BUILD/builder.o"
  OBJECTS+=("$BUILD/builder.o")
fi

"$CXX" -isysroot "$SDK" -arch arm64 -miphoneos-version-min=17.0 \
  "${OBJECTS[@]}" \
  -framework UIKit \
  -framework Foundation \
  -o "$APP/$APP_NAME"

cp Info.plist "$APP/Info.plist"

mkdir -p "$ROOT/Payload"
cp -R "$APP" "$ROOT/Payload/"

/usr/bin/zip -qry "$ROOT/${APP_NAME}_Unsigned.ipa" "$ROOT/Payload"

echo "IPA created:"
ls -lh "$ROOT/${APP_NAME}_Unsigned.ipa"
