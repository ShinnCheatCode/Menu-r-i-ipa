# Menu-r-i-ipa

## Build IPA

Workflow: `.github/workflows/build.yml`

- Push to `main`/`master`, or run **Build ShinnThieuu IPA** manually from GitHub Actions.
- The workflow builds an arm64 iOS app from the existing `main.m` + `AppDelegate.mm`.
- It packages the result as `ShinnThieuu_Unsigned.ipa`.

The original source files are kept in the repository. The two source filenames that contained an invisible Unicode character were normalized to `main.m` and `Info.plist` so Xcode/clang and GitHub Actions can read them reliably.

This workflow creates an **unsigned** IPA. Installing it on a device still requires an appropriate signing/sideloading method.
