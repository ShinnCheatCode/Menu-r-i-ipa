#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
CC="$(xcrun --sdk iphoneos -f clang)"
CXX="$(xcrun --sdk iphoneos -f clang++)"
BUILD="$ROOT/build"
APP="$BUILD/ShinnThieuuApp.app"
rm -rf "$BUILD" "$ROOT/Payload" "$ROOT/ShinnThieuuApp_Unsigned.ipa"
mkdir -p "$APP"
CFLAGS=(-isysroot "$SDK" -arch arm64 -miphoneos-version-min=17.0 -fobjc-arc -I"$ROOT")
"$CC" "${CFLAGS[@]}" -c main.m -o "$BUILD/main.o"
"$CXX" "${CFLAGS[@]}" -c AppDelegate.mm -o "$BUILD/AppDelegate.o"
OBJECTS=("$BUILD/main.o" "$BUILD/AppDelegate.o")
if [ -f builder.mm ]; then
  "$CXX" "${CFLAGS[@]}" -c builder.mm -o "$BUILD/builder.o"
  OBJECTS+=("$BUILD/builder.o")
fi
"$CXX" -isysroot "$SDK" -arch arm64 -miphoneos-version-min=17.0 \
  "${OBJECTS[@]}" -framework UIKit -framework Foundation \
  -o "$APP/ShinnThieuuApp"
cp Info.plist "$APP/Info.plist"
for f in localConfig.json Assembly-CSharp-patch.bytes; do
  [ -f "$f" ] && cp "$f" "$APP/$f"
done
plutil -lint "$APP/Info.plist"
mkdir -p "$ROOT/Payload"
cp -R "$APP" "$ROOT/Payload/"
zip -qry "$ROOT/ShinnThieuuApp_Unsigned.ipa" "$ROOT/Payload"
echo "IPA: $ROOT/ShinnThieuuApp_Unsigned.ipa"
